import os
LOCAL_PATH = os.getcwd()
CONF_PATH = LOCAL_PATH+'/conf'
REG_CONF_FILE = '/registered_controller.json'
CONTROLLER_ALIAS = '/controller_alias.json'

FLOW_PATH = LOCAL_PATH+'/flows'
